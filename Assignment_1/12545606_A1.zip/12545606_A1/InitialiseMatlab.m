function InitialiseMatlab()
%INITIALISEWORKSPACE Initialise workspace
%   Dock figures, clear all and
clear all;
clc;
clf;
set(0,'DefaultFigureWindowStyle','docked');
run /Users/jonathanwilde/MATLAB-Drive/rvctools/startup_rvc.m
end

